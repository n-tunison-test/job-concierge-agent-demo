# Source of truth (template)

Fill every section. Facts here are treated as verified by all other skills. Mark unknowns `[TO CONFIRM]`.

## Target direction
- Roles and level:
- Industries (include / avoid):
- Compensation floor (base / total):
- Location rules (home location, commute radius, remote preference):
- Must-haves and dealbreakers:
- What I want more of / less of:

## What matters to me (drives the job search digest)
Rank these. The scout and the fit call use this order.
- Must-haves (a role without these is a no):
- Strong preferences (move a role up the list):
- Deal-breakers:
- Priorities to trade off (cash, level, scope, mission, flexibility, location, team):
- Companies or domains I want or want to avoid:

## Positioning
- Tagline:
- Summary (3 to 4 sentences):
- Themes (3 to 5, each tied to at least two accomplishments):

## Experience
Repeat per employer, newest first.

### Employer name — City (dates, as they appear on the resume)
- Title(s) and dates:
- Scope (team size, budget, users, revenue):
- Accomplishments. One bullet each, format: Action, Scope, Result.
  - [lead | co-lead | contribute] Bullet text with exact metric.

## Portfolio and work samples
Add as many as you can. Each entry helps the digest judge fit and gives the resume tailor more true evidence to choose from.
- Title and link (or where it lives):
- What it is and what it shows (one or two sentences):
- Your role (lead, co-lead, contribute) and the result, with numbers:
- Relevant to which kinds of roles:

## Additional accomplishments not on the resume
(Action, scope, result, and your level of ownership. More specific detail means better matches.)

## Tools and platforms hands-on
(Only tools you have actually used. Skills will not claim anything outside this list.)

## Education and certifications

## Decisions
(Wording the user approved or rejected, words to never use, naming conventions.)

## Gaps
(What target roles ask for that this record does not show, and how to handle each.)
