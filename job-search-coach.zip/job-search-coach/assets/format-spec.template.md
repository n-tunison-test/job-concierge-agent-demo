# Resume format spec (template, edit to taste)

- Length: 2 pages maximum, roughly 900 to 1,050 words when the record supports it; shorter is fine, never pad.
- Header: name and contact line (name, city, email, phone, LinkedIn) come from the Profile's `Resume format spec` section.
- Order: bold tagline, summary paragraph with no heading, Skills and Tools, Experience, Education.
- Experience entries: Employer, City then dates on the same line separated by ` | ` (Google Docs cannot right-align). Title below in italics. 3 to 6 plain bullets, strongest and most relevant first. Each bullet: action, scope, result with the exact metric.
- Fonts and style: one readable font, 10 to 11 pt, no tables, no columns, no graphics (applicant tracking systems parse plain structure best).

## Cut order when over length
1. Oldest role bullets, keeping at least 2 per employer.
2. Bullets with no metric.
3. Skills the posting does not mention.
4. Summary length (never below 2 sentences).
Never cut a metric from a bullet that stays. Never drop an employer.
