#!/usr/bin/env python3
"""Build dashboard data from the job search tracker. Writes two files:

  data.js        PRIVATE view: counts plus "roleList" (company, role, stage, outcome,
                 source, date applied) so the dashboard can show the roles behind each
                 number. Keep this file and any page built from it to yourself.
  data.share.js  SHARE-SAFE view: counts only. It has no "roleList" key, and the script
                 checks that no company name or role title appears anywhere in it.

Usage: python3 build_data.py path/to/Job_Search_Tracker_v2.xlsx [out_dir]
Export the Tracker file from Google Sheets (File > Download > .xlsx) first.
Links, contact names, notes, emails and salary are never written to either file.
"""
import sys, json, datetime, collections
import openpyxl

STAGES = ["Saved", "Tailored", "Applied", "Phone screen", "Interview 1", "Interview 2", "Offer"]
MIN_N = 3  # categories with fewer applications than this are folded into "Other"

def iso(v):
    """Date cell to yyyy-mm-dd, or None when blank."""
    if isinstance(v, datetime.datetime):
        return v.date().isoformat()
    return v.isoformat() if isinstance(v, datetime.date) else None

def load(path):
    ws = openpyxl.load_workbook(path, data_only=True)["Tracker"]
    head = [c.value for c in ws[1]]
    col = {h: i for i, h in enumerate(head)}
    rows = []
    for r in ws.iter_rows(min_row=2, values_only=True):
        if not r[col["Company"]]:
            continue
        g = lambda k: r[col[k]]
        cohort = g("Cohort") or ""
        if not (cohort.startswith("Baseline") or cohort == "Tailored"):
            continue
        stage = g("Furthest stage") or "Saved"
        rows.append(dict(
            cohort=cohort,
            warm=(g("Warm contact") == "Yes"),
            stage=STAGES.index(stage) + 1 if stage in STAGES else 0,
            outcome={"Withdrawn": "Withdrew"}.get(g("Outcome"), g("Outcome")) or "Active",
            industry=g("Industry") or "Other / not recorded",
            discipline=g("Discipline") or "Other / not recorded",
            source=g("Source") or "Other / not recorded",
            month=g("Month applied (month-level)"),
            version=(g("Resume version") or ""),
            co=str(g("Company")).strip(),
            role=str(g("Role") or "").strip(),
            applied=iso(g("Date applied")),
        ))
    return rows

def applied(r):
    return r["stage"] >= 3 and r["outcome"] != "Skipped"

def rates(rs):
    a = [r for r in rs if applied(r)]
    return dict(applied=len(a),
                screens=sum(r["stage"] >= 4 for r in a),
                interviews=sum(r["stage"] >= 5 for r in a))

def breakdown(rows, key, order=None):
    groups = collections.defaultdict(list)
    for r in rows:
        if applied(r):
            groups[r[key]].append(r)
    other = []
    out = []
    for k, rs in groups.items():
        if len(rs) < MIN_N or k.startswith("Other"):
            other += rs
        else:
            out.append((k, rs))
    out.sort(key=lambda kv: -len(kv[1]))
    if other:
        out.append(("Other / not recorded", other))
    res = []
    for k, rs in out:
        d = rates(rs)
        d["name"] = k
        d["rejected"] = sum(r["outcome"] == "Rejected" for r in rs)
        d["no_response"] = sum(r["outcome"] == "No response" for r in rs)
        d["warm"] = sum(r["warm"] for r in rs)
        res.append(d)
    return res

def months(rows):
    g = collections.defaultdict(list)
    for r in rows:
        if applied(r) and isinstance(r["month"], (datetime.date, datetime.datetime)):
            g[(r["month"].year, r["month"].month)].append(r)
    res = []
    for (y, m) in sorted(g):
        d = rates(g[(y, m)])
        d["name"] = datetime.date(y, m, 1).strftime("%b %Y")
        res.append(d)
    return res

def sankey(rows):
    n = collections.Counter()
    A = [r for r in rows if applied(r)]
    skipped = sum(r["outcome"] == "Skipped" for r in rows)
    inprep = sum(1 for r in rows if r["stage"] < 3 and r["outcome"] != "Skipped")
    links = [("Found", "Applied", len(A))]
    if skipped: links.append(("Found", "Skipped", skipped))
    if inprep: links.append(("Found", "In prep", inprep))
    names = {3: "Applied", 4: "Phone screen", 5: "Interview 1", 6: "Interview 2", 7: "Offer"}
    for s in range(3, 7):
        nxt = sum(r["stage"] >= s + 1 for r in A)
        links.append((names[s], names[s + 1], nxt))
        at = [r for r in A if r["stage"] == s]
        lab = {"Rejected": "Rejected", "No response": "No response", "Withdrew": "Withdrew", "Active": "Still active"}
        for o, label in lab.items():
            c = sum(r["outcome"] == o for r in at)
            links.append((names[s], f"{label}|{names[s]}", c))
    return [dict(source=a, target=b, value=v) for a, b, v in links]

def main():
    src = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else "."
    rows = load(src)
    A = [r for r in rows if applied(r)]
    data = dict(
        updated=datetime.date.today().isoformat(),
        roles=len(rows), applied=len(A),
        skipped=sum(r["outcome"] == "Skipped" for r in rows),
        funnel=[dict(stage=names, n=sum(r["stage"] >= i for r in A))
                for names, i in [("Applied", 3), ("Phone screen", 4), ("Interview 1", 5), ("Interview 2", 6), ("Offer", 7)]],
        sankey=sankey(rows),
        outcomes={o: sum(r["outcome"] == o for r in A) for o in ["Active", "No response", "Rejected", "Withdrew"]},
        cohort=[dict(name=n, **rates([r for r in rows if r["warm"] == w and (r["cohort"].startswith("Baseline") if n == "Baseline" else r["cohort"] == n)]), warm=w)
                for n in ["Baseline", "Tailored"] for w in [False, True]],
        version=[dict(name=v, **rates([r for r in rows if r["version"] == v])) for v in ["Baseline v1", "Baseline v2", "Tailored"]],
        industry=breakdown(rows, "industry"),
        discipline=breakdown(rows, "discipline"),
        source=breakdown(rows, "source"),
        month=months(rows),
    )
    # share-safe copy first: counts only, then verify nothing identifying leaked in
    safe = json.dumps(data, indent=1)
    for r in rows:
        for name in (r["co"], r["role"]):
            if len(name) > 3 and name.lower() in safe.lower():
                sys.exit(f"Refusing to write the share-safe file: '{name}' appears in it.")
    with open(f"{out}/data.share.js", "w") as f:
        f.write("window.TRACKER_DATA = " + safe + ";\n")
    # private copy: same counts plus the roles behind them
    private = dict(data)
    private["roleList"] = [dict(co=r["co"], role=r["role"], stage=r["stage"], outcome=r["outcome"],
                                source=r["source"] if r["source"] != "Other / not recorded" else "Other",
                                applied=r["applied"]) for r in rows]
    with open(f"{out}/data.js", "w") as f:
        f.write("window.TRACKER_DATA = " + json.dumps(private, indent=1) + ";\n")
    print("roles", data["roles"], "applied", data["applied"], "funnel", [x["n"] for x in data["funnel"]])
    print("wrote data.js (private, with roleList) and data.share.js (counts only)")

main()
