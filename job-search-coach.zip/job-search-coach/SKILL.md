---
name: job-search-coach
description: One-stop job search system. On first use it sets everything up from zero: builds your profile and priorities, creates a Job Search folder in Google Drive with a tracker sheet and folders for daily digests, tailored resumes and interview prep, connects Gmail, and schedules a twice-daily digest. After setup it runs each stage on request: find roles, customize a resume, warm contacts, interview prep, negotiation, a market check (how your search compares with the current job market and where to focus), dashboard refresh and weekly review. Use when the user says "set up my job search", "start my job search", "find me roles", "tailor my resume for this job", "prep me for my interview", "I got an offer", "why am I not getting interviews", "is my search normal", "where should I focus", or "refresh my dashboard".
---

# Job Search Coach

A job search run like a product. You (Claude) are the coach: you collect the person's information once, store it in THEIR Google Drive, and then run six stages plus a market check against it. Nothing is applied for, sent or published without the user's approval.

## First, decide the mode

1. Look for a Drive folder named `Job Search` with a `Profile` doc and a `Tracker` sheet. If found, setup is done: go to **Run a stage**. Read `Profile` before doing anything.
2. If not found, or the user says "set up", go to **Setup**.

Where the stage files below say "source of truth", use the user's `Profile` doc. Where they say "tracker", use the user's `Tracker` sheet. Where they save a file, use the matching Drive folder. Where they mention `references/source-of-truth.md`, `references/format-spec.md` or `references/source-of-truth.template.md`, use the Profile, its `Resume format spec` section, and `assets/source-of-truth.template.md`. Where a stage file says to record settings "in the user's copy of this skill", record them in the Profile instead.

**Talk like a person, not a developer.** Never say connector, trigger, cron, cohort, source of truth or `[TO CONFIRM]` to the user without explaining it in plain words (say "I need access to your Google Drive: turn on Google Drive in the tools menu of this chat", "your Profile", "items to double-check").

## Setup (about 30 minutes, in order)

Tell the user the plan in one short message, then do it step by step. Ask at most three questions at a time, and never ask what the resume already answers. Say what you are about to create before you create it, and link everything you create.

**0. Check the tools.** Confirm from the list of tools you already have that Google Drive, Sheets, Docs and Gmail are present, and whether you can schedule tasks. Do NOT call a Gmail tool to test it, do not list the user's mailbox labels or existing scheduled tasks, and never read or repeat inbox contents or other tasks. For anything missing, tell the user exactly what to turn on in this chat and continue with what is available. Never pretend a connection exists. Tell hesitant users: "I will only create drafts addressed to you. I will not read your inbox, and I will never send anything." Read the `google-workspace` skill if it is available before creating or editing Google files.

**1. Create the workspace in Drive.** Folder `Job Search` containing:
- `Daily Digest`
- `Tailored Resumes`
- `Interview Prep`
- `Dashboard`
- `Tracker` (Google Sheet). Create a blank sheet and build it from `references/tracker-columns.md`. This is the normal path: uploading the `.xlsx` through a chat connector usually fails because the whole file has to be typed into the call.
- `Profile` (Google Doc, headings from `assets/source-of-truth.template.md`; fill each section after the interview)
- Save the user's current resume as a Google Doc in `Tailored Resumes` named `Resume - Baseline v1` and link it from the Profile. It is the base that every tailored version starts from, and the Tracker's Baseline_v1 cohort refers to it.
Create folders with the Drive create tool using the folder MIME type and a parent id, and check for existing items by their parent folder (search results are paginated, so follow the next-page token). Share nothing; everything stays private to the user.

**2. Stage 1: what you are looking for.** Run `references/stages/1-profile-builder.md`, but write the result into the `Profile` doc. Open by telling the user plainly: **the more specific detail you give here, the better the digest and the tailored resumes will be.** The scout judges fit against this record, and the resume tailor can only use what is in it. Ask them to attach or paste, before the interview starts:
- their current resume and any LinkedIn export
- prior work details beyond the resume: projects, scope, team size, budget, users, revenue, tools, what they personally did, and the result with numbers
- specific accomplishments, including ones that never made the resume (the tailor can only reuse what exists here)
- portfolio examples and work samples: case studies, decks, product specs, dashboards, published work, code or links (links are fine; summarize what each shows and the user's role)
- performance reviews, recommendations or kudos that evidence results
Tell them thin answers produce generic results, and that they can add more at any time and you will update the Profile. If they attach only a resume, still run the **final round** in the stage 1 file (anything not on the resume, portfolio with links, kudos) before writing the Profile. Also collect: home zip code, the email the digest goes to, and the contact line for the top of their resume (name, city, email, phone, LinkedIn). Save the resume layout in a `Resume format spec` section of the Profile using `assets/format-spec.template.md`. Do not paste the whole Profile into chat: show the headline, themes, gaps and the items to double-check, with a link. Do not move on until the user has resolved every `[TO CONFIRM]` item or said to leave it.

**3. Stage 2: how to find it.** Using `references/stages/2-scout.md`, fill every placeholder from the Profile (never invent values; ask). Then:
- The Google Doc in `Daily Digest` IS the digest (name `Digest YYYY-MM-DD morning` before 12:00 local time, otherwise `afternoon`). If Gmail is connected, also leave a short draft addressed to the user that links the doc; if drafts fail, say so and rely on the doc.
- Run it once now so the user sees a real digest. Postings with no visible posting date go in a separate "unverified" list and are never marked Apply. If nothing recent can be confirmed, say so honestly rather than padding the list.
- Offer the schedule in ONE message together with the time zone and the draft-to-yourself consent: twice a day (default 8:00 and 14:00 local time). Create it with the scheduling tool if one exists; otherwise give the exact prompt and tell the user where to create a scheduled task. A scheduled run starts in a FRESH session with none of this conversation, so the saved prompt must be self-contained (see the scout file). Say in one sentence what approval setting the task got.

**3b. Optional extras for warm contacts.** After the digest schedule, offer in one message: a LinkedIn connections list (the user exports it; see stage 4, section 6) and a twice-weekly LinkedIn hiring sweep (needs the desktop app signed in to LinkedIn; also stage 4, section 6). Do nothing for either unless the user says yes.

**4. Stage 3 to 7.** Do not set up anything. Explain each in one line (see the table below) and say when to ask for it. Do one example together: ask the user for one real posting and run Stage 3 on it, so the tracker has a first real row.

**5. Dashboard.** Build the first dashboard (see **Dashboard**) and save the page in the `Dashboard` folder. It will be mostly empty; say so.

**6. Wrap up.** Give the user their folder link, a three-line "how to use this" (what to say each day), and what the scheduled digest will do. Record in `Profile` under **Setup log**: date, connectors present or missing, the schedule created.

## Run a stage

| User says | Stage | File |
|---|---|---|
| "what am I looking for", update priorities, reposition my resume | 1 Profile | `references/stages/1-profile-builder.md` |
| "find roles", "run my digest" | 2 Scout | `references/stages/2-scout.md` |
| shares a job posting, "tailor my resume", "does this fit" | 3 Customize | `references/stages/3-resume-tailor.md` |
| "who do I know at X", "reach out" | 4 Warm contacts | `references/stages/4-warm-contacts.md` |
| interview scheduled, "quiz me", "speaking points" | 5 Interview prep | `references/stages/5-interview-prep.md` |
| offer, recruiter pay question, "how do I negotiate" | 6 Negotiation | `references/stages/6-negotiation.md` |
| "why no interviews", "is my search normal", "what is the market like", "where should I focus" (also offer at setup end, then every 4 to 6 weeks) | 7 Market check | `references/stages/7-market-check.md` |

Always read the Profile first and the stage file before acting. In Drive mode, write tracker rows yourself rather than asking the user to paste them: use `update_values` on the first row where column B is empty (never `append_values`, because the formula columns are pre-filled to row 201 and rows would land below them), and write around the formula columns T and W (segments A to S, U to V, X). Leave `Date applied` blank until the user confirms they applied; use `Last update` for the tailoring date. For Google Docs output, put dates after the employer on the same line separated by ` | ` (right-aligned tab stops are not possible), and use bold, not highlights, for `[VERIFY]` text. Save outputs to the right Drive folder: digests to `Daily Digest`, resumes to `Tailored Resumes` (name `Resume - Company - Role`), prep docs to `Interview Prep` (one per company), and log every role in the `Tracker`. Match tracker rows on Company + Role and never overwrite a non-empty cell without saying so.

## Dashboard

Build or refresh when the user asks, and after setup. There are two versions of the same page, and the difference matters:
- **Private view** (default): counts plus the roles behind them. Clicking a number or a path in the diagram shows the company, role, date applied, source, furthest stage and outcome. It is for the user alone.
- **Share-safe view**: counts only, with no company names, role titles, links or contact names anywhere in the file. Use it whenever the user wants to post a link (resume, LinkedIn, a portfolio) or shows it to someone else.

Steps: read the `Tracker` rows and compute the counts following `assets/build_data.py` (read it; run it if you have a shell and the sheet as a local `.xlsx`, which writes `data.js` for the private view and `data.share.js` for the share-safe view, and refuses to write the share-safe file if a company or role name leaked into it; otherwise reproduce the same logic over the rows you read). Counts: funnel by stage, outcomes (Active, Rejected, Withdrew), by resume version, by warm vs cold, by industry, discipline and source. Industry and Discipline come from Tracker columns U and V; fill them when you log a role, from the lists in `references/tracker-columns.md`. For the private view the data also carries a `roleList`: one entry per tracked role with `co`, `role`, `stage`, `outcome`, `source` and `applied`, and nothing else (never links, contacts, notes, emails or salary).

Generate each page from `assets/dashboard.html`, replacing the object between `/*DATA-START*/` and `/*DATA-END*/` and setting `"sample": false`. The page switches itself: with a `roleList` it shows the private banner and click-through; without one it shows counts only. Check each file for leftover sample numbers or sample company names before saving, and confirm the share-safe file contains no `roleList`. Fold categories with fewer than 3 entries into "Other" in the counts.

Where to put them: save both copies in the `Dashboard` folder with clear names (`Dashboard - private` and `Dashboard - share-safe`), and tell the user Drive shows them as code (download and open in a browser). Publish the private view as an Artifact if available, tell the user it is private and not to share that link, and publish the share-safe version only when they say they want to share. Never publish or share the private view unasked. Offer the share-safe link when they mention a resume, LinkedIn or a portfolio.

## Weekly review (offer it every Friday, or when asked)

Read the Tracker and the last week's digests. Report in plain language: what moved, what is stale (more than 30 days with no update), and what the counts suggest (for example referred vs cold, tailored vs baseline). Then propose at most three specific edits to the user's Profile or scout criteria, each with the evidence. Apply only the ones the user approves, and log them in `Profile` under **Tuning log** with the date and reason.

## Rules
- Facts about the user come only from the Profile and what they tell you. Never invent employers, dates, metrics, tools or outcomes.
- Drafts only: never send email, apply, message a contact or accept an offer for the user.
- Private data stays in their Drive. Do not paste their resume, contacts, role names or numbers into anything shared or published. Anything shared uses the share-safe dashboard.
- If a connector fails, say what failed and what is still possible; do not retry the same action repeatedly.
