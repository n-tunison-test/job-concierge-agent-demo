# Tracker columns (fallback if the xlsx cannot be uploaded)

Sheet name `Tracker`, header row in row 1; freeze row 1 and columns A to B. Keep 201 rows by 24 columns. Columns A to X:

A Date applied (yyyy-mm-dd) | B Company | C Role | D JD link | E Source | F Cohort | G Fit call | H Fit notes / gaps | I Resume link (version sent) | J Warm contact (Yes/No) | K Contact name | L Recruiter outreach | M Salary range | N Furthest stage | O Outcome | P Last update | Q Next action | R Next action date | S Notes | T Month applied (month-level) | U Industry | V Discipline | W Resume version | X Prep doc

Formulas: write row 2 with the formula tool, not as text, then copy it down to row 201 with `copyPaste` (PASTE_FORMULA) in `update_spreadsheet`:
- T: `=IF(OR($B2="",$A2=""),"",DATE(YEAR($A2),MONTH($A2),1))` (format `mmm yyyy`)
- W: `=IF(OR($B2="",$O2="Skipped"),"",SUBSTITUTE($F2,"_"," "))`

Number formats: column A `yyyy-mm-dd`, column T `mmm yyyy`.

Dropdowns: add list validation (ONE_OF_LIST, rows 2 to 201) to columns E, F, G, J, N and O using the allowed values below.

Allowed values:
- Cohort: Baseline_v1, Baseline_v2, Tailored, Scouted
- Fit call: Apply, Stretch, Skip
- Warm contact: Yes, No
- Furthest stage: Saved, Tailored, Applied, Phone screen, Interview 1, Interview 2, Offer
- Outcome: Active, Rejected, Withdrawn, Skipped, Offer
- Source: LinkedIn, Greenhouse, Company site, Referral, Recruiter, Indeed, Other
- Industry (column U): Health tech, Fintech, B2B SaaS, Media, Retail, Marketplace, AI / ML, Other
- Discipline (column V): Product, Platform, Data / AI, Growth, Other

Rules: leave `Date applied` blank until the user confirms they applied. Write rows with `update_values` to the first row where column B is empty, never `append_values`.
