# Tracker columns (fallback if the xlsx cannot be uploaded)

Sheet name `Tracker`, header row in row 1; freeze row 1 and columns A to B. Keep 201 rows by 24 columns. Columns A to X:

A Date applied (yyyy-mm-dd) | B Company | C Role | D JD link | E Source | F Cohort | G Fit call | H Fit notes / gaps | I Resume link (version sent) | J Warm contact (Yes/No) | K Contact name | L Recruiter outreach | M Salary range | N Furthest stage | O Outcome | P Last update | Q Next action | R Next action date | S Notes | T Month applied (month-level) | U Industry | V Discipline | W Resume version | X Prep doc

Formulas: write row 2 with the formula tool, not as text, then copy it down to row 201 with `copyPaste` (PASTE_FORMULA) in `update_spreadsheet`:
- T: `=IF(OR($B2="",$A2=""),"",DATE(YEAR($A2),MONTH($A2),1))` (format `mmm yyyy`)
- W: `=IF(OR($B2="",$O2="Skipped"),"",SUBSTITUTE($F2,"_"," "))`

Number formats: column A `yyyy-mm-dd`, column T `mmm yyyy`.

Dropdowns: add list validation (ONE_OF_LIST, rows 2 to 201) to columns E, F, G, J, N and O using the allowed values below.

Allowed values:
- Cohort: Baseline_v1, Baseline_v2, Tailored, Scouted
- Fit call: Apply, Stretch, Skip
- Warm contact: Yes, No
- Furthest stage: Saved, Tailored, Applied, Phone screen, Interview 1, Interview 2, Offer
- Outcome: Active, Rejected, Withdrawn, Skipped, Offer
- Source: LinkedIn, Greenhouse, Company site, Referral, Recruiter, Indeed, Other
- Industry (column U): Health tech, Fintech, B2B SaaS, Media, Retail, Marketplace, AI / ML, Other
- Discipline (column V): Product, Platform, Data / AI, Growth, Other

Rules: leave `Date applied` blank until the user confirms they applied. Write rows with `update_values` to the first row where column B is empty, never `append_values`.

## Criteria tab

Create a tab named `Criteria` as the first tab after `Tracker`, with columns A Area, B Setting, C Value, D Used by, and freeze row 1. It is the single place the user's search rules live: the scheduled digest, hiring sweep and weekly review read it at the start of every run, so the user edits one cell here instead of rewriting a scheduled task. Fill it from the Profile interview, one setting per row:

- Level: target roles and levels (note that titles vary; do not exclude one level up or down)
- Pay: base floor, total comp floor or guideline (say which is a hard cutoff), what to do when pay is not listed
- Location: home zip, remote rule, hybrid or onsite commute rule
- Freshness: look-back window in days (default 7)
- Industries: include and exclude lists
- Fit: must-haves, deal-breakers, ranked priorities, and any calibration the user gives (for example "hands-on data engineering counts as a gap")
- Sweep: the LinkedIn search URL and pace limits, if the hiring sweep is on
- Network: date of the connections export and its maximum age (default 45 days)
- Log: one row recording each change, with the date and reason

Shade column C so it is clear that only the values are edited.

## Screened out tab

Create a tab named `Screened out` with columns A Date screened, B Company, C Role, D Link, E Reason, F Recheck after, G Run, and freeze row 1. The digest adds one row for each posting it rejects and skips anything listed here until its Recheck after date, so it does not re-check the same closed or out-of-area postings every run.
