---
name: profile-builder
description: Starts the job search by capturing what you are looking for and what matters to you, then interviews you about your career and builds the "source of truth" file that every other job search skill relies on, plus a positioning statement that highlights your expertise and best accomplishments. Use when starting a job search, repositioning your resume for a new direction, or when the source of truth is missing, thin or out of date.
---

# Profile Builder

Build the one file every other skill reads from: a verified record of your experience, written so that accomplishments are specific and the positioning is deliberate. Nothing in it may be invented. If the user does not know a number, mark it `[TO CONFIRM]` instead of estimating.

## Inputs

- The user's current resume, LinkedIn export, performance reviews, portfolio links and work samples, and any notes they attach. Read all of them first, and ask for more if the material is thin.
- The target direction in the user's words: roles, level, industries, and what they want to do more or less of.
- `assets/source-of-truth.template.md` (structure of the output).

## Workflow

### 0. Set expectations
Tell the user at the start: the more specific prior work details, accomplishments and portfolio examples they add, the better the job search digest and the tailored resumes will be, because both can only draw on what is in the source of truth. Invite them to attach portfolio links, case studies, decks, specs, reviews and recommendations, and to add more later.

### 1. Read before asking
Extract employers, titles, dates, scope, tools and metrics from what was provided. Build a draft of the source of truth from it. Ask questions only about what is missing or unclear, never about what the documents already answer.

### 2. Interview in rounds (max 3 questions per message)
Round 1 (also collect home zip code and the email for the digest): what they are looking for, and what is specific or important to them: target roles and level, compensation floor, location, industries to include or avoid, must-haves, dealbreakers, what they want more or less of. Save this under Target direction; the scout agent reads it.
Round 2 onward: one role at a time, newest first. For each accomplishment, get the shape **Action, Scope, Result**:
- What did you personally do (not the team)?
- Scope: team size, budget, users, revenue, systems, geographies.
- Result: a number if one exists, else the observable outcome. Ask "how would you know it worked?"
- Evidence level: did you **lead**, **co-lead**, or **contribute**? Record it. Later skills must not raise it.

**Final round (never skip, even if they said they have nothing handy).** Before writing the Profile, ask one short question each: "Anything you did that is not on your resume?", "Do you have portfolio items or work samples, with links?", "Any kudos, reviews or recommendations?" Record each answer in the matching Profile section.

### 3. Find the themes
Group accomplishments into 3 to 5 themes that match the target direction (for example "0 to 1 product launches", "platform scale", "regulated domains"). A theme needs at least two supporting accomplishments with different employers or contexts, otherwise it is an anecdote.

### 4. Write the positioning
- **Headline tagline**: one line, role plus differentiator.
- **Summary**: 3 to 4 sentences, built only from verified facts. Lead with the strongest theme for the target direction.
- **Proof points**: the 6 to 8 strongest accomplishments, each with its metric.
- **Gaps and how to address them**: honest list of what the target roles ask for that the record does not show.

### 5. Output
Do not paste the whole file into chat. Show the tagline, themes, honest gaps and the `[TO CONFIRM]` list, with a link to the file. Show a short list of items marked `[TO CONFIRM]` and ask the user to resolve them. Offer to save the file where the other skills can read it.

## Rules
- Never invent employers, titles, dates, metrics, team sizes, tools or outcomes.
- Never upgrade ownership (contributed to, co-led, led) beyond what the user states.
- Keep a **Decisions** section recording any wording the user approved or rejected (for example a banned phrase), so later skills respect it.
