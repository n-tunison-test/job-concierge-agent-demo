---
name: warm-contacts
description: Finds and prioritizes warm paths into a target company and drafts honest outreach. Use when the user has a target role or company and wants to know who they know there, who to ask for a referral, or what to say, or when reviewing which tracker rows have no warm contact yet.
---

# Warm Contacts

Referred applications convert far better than cold ones. This skill turns a target role into a short, ranked list of people to contact and a message each person will actually answer. It never sends anything without approval.

## Inputs

- Target company and role (from the tracker or the user).
- The user's contact sources: an export of connections, their email, a list they paste. Ask which to use. Only search sources the user has connected or provided.
- The source of truth, for accurate framing of the user's background.

## Workflow

### 1. Build the candidate list
Search the allowed sources for people at the company, formerly at the company, or at companies tightly linked to it (investors, partners, alumni of the same employers or schools). Record per person: name, relationship, last contact date, how they are connected to the role (same function, hiring-adjacent, executive, peer).

### 2. Rank
Order by: (1) can influence this hiring decision, (2) relationship warmth and recency, (3) relevance to the role's function. Keep the top 3. For each, say why in one line. If there is no warm path, say so and propose the nearest second-degree route (who might introduce) instead of inventing a connection.

### 3. Draft outreach
One short message per person, in the user's voice if a writing-style skill exists:
- Reference the real relationship in the first line.
- One specific ask (an intro, 15 minutes, a referral), never several.
- Include the role link and a one-sentence reason they fit. No flattery, no exaggeration.
- Under 90 words. Offer the user an easy way out for the contact.

Deliver as drafts the user reviews. Create email drafts only if the user asks. Never send.

### 4. Update the tracker
After the user acts, set Warm contact to Yes, fill Contact name, set Next action ("Follow up with X") and Next action date about 5 business days out.

### 5. Weekly sweep (optional)
List tracker rows with Warm contact = No and fit call Apply, ranked by how recently posted. Run steps 1 to 3 for the top five.

### 6. LinkedIn connections and hiring sweep (optional extras)
Offer these once, at setup or the first time the user asks about warm contacts. Both are optional and the user decides.

**Connections list.** Claude cannot see a LinkedIn account, so it works from the user's own export. Ask them to request it in LinkedIn (Settings and privacy, Data privacy, Get a copy of your data, Connections) and put the CSV in the `Job Search` Drive folder. Load name, company, title and profile URL (never emails) into a `Connections` tab of the Tracker. When a role is logged, match its company to this tab (ignore case, punctuation and suffixes such as Inc or LLC; treat a parent and its units as one employer; do not match look-alike names) and list up to 3 people as first-degree connections. Say when the export is older than 45 days and offer a refresh.

**Twice-weekly hiring sweep.** Finds people at companies who currently show LinkedIn's "Actively hiring" tag for the user's target titles and area, and points the user at the ones who own roles they want. It needs the Claude desktop app open and the user signed in to LinkedIn in its built-in browser, because LinkedIn blocks signed-out viewing. Claude never types a password.
1. Ask the user to build a LinkedIn people search with the "Actively hiring" filter, their target titles and their area, then paste the URL.
2. Add a `Hiring sweep` tab to the Tracker: Profile URL, Name, Their title, Company, Degree, Hiring for, Location and mode, Role posted (est.), First seen, Last seen, Status, Screen, Tracker match, Notes.
3. Create a scheduled task (default Tuesday and Friday morning) with a self-contained prompt that contains the search URL, the sheet id, the user's criteria and these rules.
Rules for every run: read only (never connect, follow, message, apply, endorse or change anything); wait 2 to 4 seconds between pages; read at most 4 result pages and 40 profiles; stop and report on any warning, CAPTCHA or sign-in page; record only professional details LinkedIn shows (no emails or phone numbers). Compare with the last sweep and mark each person New, Still open, Gone or Stale (posted over 60 days ago), never deleting rows. Screen each new or changed person as Pursue, Review, In tracker, Out of area or Not a fit, then add a short section to the digest and send a notification with the counts and the Pursue names. Never edit the user's own application rows; just note any match.
Tell the user plainly that LinkedIn's terms restrict automated access, so this is their choice: it runs slowly, read only, on their own signed-in session.

## Rules
- Never claim a relationship that the source does not show.
- Never contact anyone on the user's behalf.
- Keep private contact details out of anything meant to be shared publicly.
