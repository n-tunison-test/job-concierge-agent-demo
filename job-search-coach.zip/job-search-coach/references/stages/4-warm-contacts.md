---
name: warm-contacts
description: Finds and prioritizes warm paths into a target company and drafts honest outreach. Use when the user has a target role or company and wants to know who they know there, who to ask for a referral, or what to say, or when reviewing which tracker rows have no warm contact yet.
---

# Warm Contacts

Referred applications convert far better than cold ones. This skill turns a target role into a short, ranked list of people to contact and a message each person will actually answer. It never sends anything without approval.

## Inputs

- Target company and role (from the tracker or the user).
- The user's contact sources: an export of connections, their email, a list they paste. Ask which to use. Only search sources the user has connected or provided.
- The source of truth, for accurate framing of the user's background.

## Workflow

### 1. Build the candidate list
Search the allowed sources for people at the company, formerly at the company, or at companies tightly linked to it (investors, partners, alumni of the same employers or schools). Record per person: name, relationship, last contact date, how they are connected to the role (same function, hiring-adjacent, executive, peer).

### 2. Rank
Order by: (1) can influence this hiring decision, (2) relationship warmth and recency, (3) relevance to the role's function. Keep the top 3. For each, say why in one line. If there is no warm path, say so and propose the nearest second-degree route (who might introduce) instead of inventing a connection.

### 3. Draft outreach
One short message per person, in the user's voice if a writing-style skill exists:
- Reference the real relationship in the first line.
- One specific ask (an intro, 15 minutes, a referral), never several.
- Include the role link and a one-sentence reason they fit. No flattery, no exaggeration.
- Under 90 words. Offer the user an easy way out for the contact.

Deliver as drafts the user reviews. Create email drafts only if the user asks. Never send.

### 4. Update the tracker
After the user acts, set Warm contact to Yes, fill Contact name, set Next action ("Follow up with X") and Next action date about 5 business days out.

### 5. Weekly sweep (optional)
List tracker rows with Warm contact = No and fit call Apply, ranked by how recently posted. Run steps 1 to 3 for the top five.

## Rules
- Never claim a relationship that the source does not show.
- Never contact anyone on the user's behalf.
- Keep private contact details out of anything meant to be shared publicly.
