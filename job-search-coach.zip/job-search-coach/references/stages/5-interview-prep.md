---
name: interview-prep
description: Builds and uses per-company interview prep docs: captures resources and notes, runs practice rounds, and gives quick speaking points on interview day. Use when the user has an interview, shares prep material or notes, asks to practice or be quizzed, or asks for speaking points for a company or role.
---

# Interview Prep

One prep doc per company (role sections inside when several roles), linked from the tracker. Three modes; pick from what the user says.

## Where things live
Prep docs go in the Drive `Interview Prep` folder, one per company; link each in the Tracker's `Prep doc` column (X). Match rows on Company + Role.

## Doc sections
1. Speaking points (one screen, scannable in 60 seconds), always first
2. Context: interviewer, date, format, referral guidance, open questions
3. Topic sections driven by the focus areas the user or a referrer names
4. Questions to ask
5. Notes log: Date | Session | What landed / what to fix, newest first, plus a story checklist

## Mode 1: Intake (user shares a resource, notes or a new interview)
- Create or extend the company doc; condense sources into the user's own frameworks, never paste wholesale.
- Record interviewer, date, format and focus areas. Update the tracker (doc link, Next action and date).
- Flag gaps and contradictions (title mismatch, missing JD) as open questions.
- Rewrite Speaking points whenever new material changes what to lead with.

## Mode 2: Practice
- Read the doc first. One question at a time, in the interviewer's voice, then wait.
- After each answer: what landed, what was missing, a tighter 2 to 3 sentence version, and one follow-up on the weakest point.
- At the end, add a Notes log row and tick off rehearsed stories.

## Mode 3: Game day
- Answer in chat, fast, fitting one phone screen. No doc edits unless asked.
  - **Open with:** 60-second intro tailored to the role
  - **Land these 3 to 4 points**
  - **If asked X, say Y:** 3 to 4 likely questions with one-line answers
  - **Ask:** the two best questions
  - **Watch out:** one or two traps (a known gap from the tracker's Fit notes)
- Afterwards offer to log a debrief and update the stage.

## Style
Top-down: headline, two or three supports, stop. Specific numbers over adjectives. Never invent experience; where a story needs the user's facts, leave a marked prompt for them to fill in.
