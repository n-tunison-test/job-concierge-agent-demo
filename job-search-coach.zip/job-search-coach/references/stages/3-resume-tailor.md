---
name: resume-tailor
description: Tailors the user's resume to a specific job posting without inventing anything. Produces a fit call, a fit analysis, a tailored resume and a change log with any stretch claims flagged for approval, and gives a tracker row to log it. Use whenever the user shares a job posting or link, or asks "does this role fit me", "tailor my resume", or which experience to emphasize.
---

# Resume Tailor

Turn one job posting into the strongest TRUE resume for that role. It never invents experience.

## Inputs

- A job posting: pasted text, a URL (fetch it) or a file. If only a title is given, ask for the full text.
- Or a tracker row: when the user says "tailor row N" (the digest prints this for every Apply role), read that row of the Tracker, fetch the JD link and start from its fit notes. The row already exists, so update it instead of giving a new one; if your fit call differs from the row's, say so and let the user decide.
- Fit calibration on the Tracker's `Criteria` tab (for example "hands-on data engineering counts as a gap"), when present.
- `references/source-of-truth.md`: the user's verified record (build it with the profile-builder skill). Read it fully every time. It is the only place facts about the user may come from.
- `references/format-spec.md`: the resume layout. Read it fully every time.

## When to customize
Customization takes effort, so spend it where it changes the odds. Default plan:
- **APPLY with a warm contact or a strong match:** full tailoring, and send it through the warm path.
- **APPLY, cold:** tailor the tagline, summary and the top bullets of the two most relevant roles (a light tailor); keep the rest of the baseline.
- **STRETCH:** tailor only after the user has a referral or new evidence. Otherwise use the baseline and keep the application short.
- **SKIP:** do not tailor. Log it and move on.
Under length is fine; never pad. Record which version was sent (Baseline_v1, Baseline_v2, Tailored) in the tracker so the dashboard can show whether tailoring helps.

## Workflow

1. **Analyze the posting.** Extract must-haves, nice-to-haves, repeated keywords, seniority and scope signals, domain, and hard filters (years, tools, location, clearance).
2. **Map requirements to evidence.** Label each must-have **Direct** (source says it plainly), **Adjacent** (related, reasonable case) or **Gap** (no real evidence; never paper over).
3. **Make the fit call.** Judge minimum qualifications and core domain first; preferred qualifications only move a borderline case.
   - **APPLY**: every minimum is Direct or strong Adjacent and the domain matches.
   - **STRETCH**: a minimum or the domain is a Gap or weak Adjacent, but an honest story exists. Say what would upgrade it (a referral, new evidence).
   - **SKIP**: several must-haves are Gaps including the core domain, or a hard filter cannot be met. Be candid. If SKIP, give the call and tracker row, then ask whether to build the full resume anyway.
4. **Draft the resume.** Allowed: reorder, choose, shorten, drop, and reword to mirror the posting's vocabulary while facts, numbers and scope stay unchanged; rewrite the tagline and summary.
5. **Flag stretch claims.** Any phrasing beyond the source (raised ownership, reframed scope, a stretched keyword) is marked `[VERIFY]` and listed with the original wording beside the new wording. Facts in the source are never flagged. Remove markers only after the user approves.
6. **Fit the page limit** in the format spec using its cut order. Never cut a metric from a bullet that stays; never drop an employer.

## Hard rules
- Never invent or alter employers, titles, dates, metrics, team sizes, tools or outcomes.
- Never change a number.
- Never claim a tool that is not in the source's tools list.
- Never raise ownership (contributed to, co-led, led) without flagging it.
- Never add a keyword only because the posting uses it.
- Respect everything under **Decisions** in the source of truth.

## Output order
0. **Fit call and tracker row.** `Fit call: APPLY | STRETCH | SKIP` and one sentence. Then a tab-separated line in a code block matching the Tracker template columns A to H: Date applied (yyyy-mm-dd) | Company | Role | JD link | Source | Cohort (`Tailored`) | Fit call | Fit notes (25 words or fewer). Leave unknown fields blank. In Drive mode write the row to the Tracker yourself and show only a one-line summary in chat; leave Date applied blank until the user says they applied.
1. **Fit analysis.** Table of requirement, evidence level, where it appears; then 2 to 4 sentences: overall fit, strongest angle, biggest gap and how to handle it.
2. **Tailored resume.** Full text per the format spec.
3. **Change log and approvals.** What changed and why (5 to 10 bullets); items needing approval (original vs. new wording); open items (gaps).

## After each use
If the user corrects a fact, tone or rule, suggest the exact edit to the source of truth so it sticks.
