---
name: market-check
description: Researches the current job market for the user's specific role, level, location and industry, compares it with their own application funnel, and says where to focus their effort. Produces a sourced market-check report with ranked changes to their search strategy, agent filters, resume rules and tracker. Use when the user asks "why am I not getting interviews", "what is the market like for my role", "where should I focus", "is my search normal", or at the start and every 4 to 6 weeks of a search.
---

# Market Check

Most job seekers can't tell whether a silent search is a market problem, a channel problem or a positioning problem. This skill answers that for one person: it researches their market, reads their own funnel, finds the stage that is holding them back, and recommends where to put effort. Everything is sourced, and anything personal stays in their own files.

## Inputs
- The user's Profile (role and level, function, domain, location rules, compensation floor, search start date, what they have tried). Ask at most three questions only for what is missing.
- Their Tracker, if it has rows. A new search with no rows still gets the market half of the report.
- `references/market-check/research-playbook.md` (what to research and where) and `references/market-check/report-template.md` (the output).
- `references/market-check/example-findings.md` is an example from one search in October 2026. Use it to see the shape of good findings. Never reuse its numbers: research again, because market data changes and is specific to a role and region.

## Workflow

### 1. Define the situation
State in one paragraph what you are checking: role and level, function and domain, geography and work-mode preference, how long they have been searching, and the funnel so far. Confirm it with the user if anything was assumed.

### 2. Research the market (current, sourced)
Follow the playbook. Search for current data on demand, competition, time to hire, search length, channel effectiveness, headcount trends for the level, what screens in the target domain, and what peers in the same situation report. For each finding record the source, its date and what it measures. Label every finding as **data** (a measured statistic), **report** (an individual account or survey) or **claim** (unsourced assertion). Say so plainly when something could not be verified or sources conflict. Never state a market number without a source and date.

### 3. Read their own funnel
From the Tracker compute, for the period the user chooses (default all time and the last 30 days): applications, screens, interviews, offers, and the conversion from each stage to the next. Break down by channel (referral and warm contact vs cold), resume version (baseline vs tailored), role title or level, domain or industry, posting age at application, and source. Show counts, not only percentages, and mark any group with fewer than 10 applications as **indicative only**. Report data quality too: blank outcomes, missing fit calls, missing dates, because comparisons rest on them.

### 3b. Find the bottleneck
Use the stage with the weakest conversion relative to the market evidence:
- **Applications to screens low:** channel, targeting or positioning. Check warm vs cold first, then role fit and title.
- **Screens to interviews low:** the screen conversation, comp or scope mismatch, or a weak story.
- **Interviews to offers low:** depth of preparation, final-round performance, references. Suggest a debrief on every final round.
- **Offers lower than hoped or not accepted:** negotiation and calibration.
- **Not enough applications at all:** sourcing; check the digest filters.
Say which bottleneck the evidence supports, and how confident you are given the sample size.

### 4. Recommend where to focus
Write 3 to 5 changes, ranked by expected impact and effort. For each: the change, the evidence (market source or the user's own numbers), the stage it helps, and who or what makes it (for example the scout filters, the warm-contacts skill, a resume-tailor rule, a Tracker column, a portfolio piece, the interview-prep skill). Add one "stop doing" item. Include what to measure and when (usually 3 to 4 weeks) to see whether the change worked.

### 5. Deliver
Produce the report per the template as a document in the user's `Dashboard` or `Job Search` folder, and give a short chat summary: the bottom line, the bottleneck and the first action. Offer, but never apply without approval: edits to the Profile, scout criteria, resume rules or Tracker columns, and a recurring weekly or monthly review. Log applied changes in the Profile's Tuning log.

## Rules
- Research first, then conclude. No generic advice that would apply to any search.
- Separate data, reports and claims. One forum thread is a report, not a trend.
- Be candid but kind: a long search at this level may be normal, and the report should say so when the evidence does.
- Small samples are indicative only. Don't claim cause and effect from a few applications.
- Never put names of companies, roles or contacts from the user's Tracker into anything shared. Aggregates only.
- Do not promise outcomes.
