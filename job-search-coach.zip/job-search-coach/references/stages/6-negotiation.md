---
name: negotiation
description: Prepares compensation and offer negotiation: researches market ranges, builds a target and walk-away, compares offers, and drafts talking points and replies. Use when the user gets a recruiter question about pay, an offer, or asks how to negotiate or compare offers.
---

# Negotiation

Help the user negotiate calmly and with evidence. Never state facts about market pay that you have not sourced, and never commit the user to anything.

## Inputs
- The offer or recruiter message (pasted, or from email), the role and level.
- The source of truth, especially **Target direction** (compensation floor, location, priorities).
- Any other offers or active interview stages from the tracker.

## Modes

### 1. Early comp question ("what are your expectations?")
Give a short, honest script that avoids anchoring low: ask for the range first; if pressed, give a range whose bottom meets the user's floor, anchored to the role and level, not to past pay. Where the law bars asking about pay history, say the user may decline to answer.

### 2. Offer analysis
- Break the offer into components: base, bonus (target and payout history if known), equity (grant value, vesting, cliff, refresh norms, strike or tax treatment), sign-on, relocation, benefits, level and title, start date, remote or hybrid terms.
- Convert to a **first-year and four-year total** with the assumptions stated. Mark equity as uncertain.
- Compare to the user's floor and to market ranges. Search for current ranges and cite each source; if no good source exists, say so.
- List what is **negotiable** in this company's situation (usually sign-on, equity and level before base) and what is not.

### 3. Strategy
Set three numbers with the user: **target**, **acceptable**, **walk-away**. Rank what matters most (cash, equity, level, flexibility, speed). Identify leverage honestly: competing offers, interview momentum, scarcity of the skill. Never bluff about offers that do not exist.

### 4. Drafts and talking points
- A reply email or call script: gratitude first, one clear ask with a reason, then stop. Offer two or three variants (cash-focused, equity-focused, level-focused).
- Likely pushbacks with replies. Always include "I'm excited and want to make this work" language only if true for the user.
- Deliver drafts for the user to edit and send. Never send.

### 5. Close
Confirm everything in writing before accepting: all numbers, level and title, start date, equity terms, and any promises made verbally. Offer to update the tracker (Outcome, Furthest stage, Notes) and the dashboard.

## Rules
- Do not give legal, tax or investment advice as certainty; point out where a professional should review equity or contract terms.
- Keep numbers the user shares private; do not put them in anything published.
