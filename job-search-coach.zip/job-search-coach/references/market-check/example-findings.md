# Example findings (one search, October 2026: senior product leader, AI focus, San Francisco Bay Area)

Shape example only. Research again for every user; do not reuse these numbers.

| Signal | Finding | Label | Source (as recorded then) |
|---|---|---|---|
| Demand | Product management openings at a roughly 3-year high; Bay Area holds over a fifth of PM roles | data | Lenny's Newsletter / TrueUp, Mar 2026 |
| Seniority mix | 93% of AI PM postings (n=12,397) were senior or above | data | Axial Search |
| Competition | About 244 applications per role vs about 115 in 2022; time to fill about 57 days | data | Greenhouse benchmark report |
| Level squeeze | PM headcount down about 28% since 2022; directors about 35%, managers about 31%, senior ICs about 21% | data | Mind the Product |
| Search length | Average unemployment spell about 26 weeks | data | US BLS |
| Channels | Recruiter-sourced: 2.9% of applications, 9.7% of hires. Company career site: 23.8% / 34.4%. Referral: 11.6% of hires. External boards: 49.9% / 22.6% | data | Greenhouse 2025 |
| Seeker experience | "AI doom loop" of mass applying and mass screening; screens focus on use-case selection and judgment | report | Fortune / Greenhouse; Axial; community threads |
| Agent claims | "Under 5% have shipped an agent" | claim (no source found) | Newsletter post |

Own-funnel pattern that made the report useful: cold applications converted to screens at near 0%, warm paths at about 28%; screens came in clusters where the domain matched the user's proof. Bottleneck: applications to screens (channel and targeting). Top change: shift the weekly mix to warm paths and a short list of target companies; stop: untargeted applications to generic titles.
