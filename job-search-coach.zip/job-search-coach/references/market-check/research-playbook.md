# Research playbook

Run current searches for each question. Prefer primary data (a published benchmark, a government series, a hiring platform's own report) over commentary. Record source, publication date and what the figure measures.

| Question | What to look for | Where to look (examples) |
|---|---|---|
| How much demand is there for this role and level? | Open roles trend, by function, level and region; senior vs junior mix | Job-market trackers (for example TrueUp), Indeed Hiring Lab, LinkedIn Economic Graph, industry newsletters that publish data |
| How crowded is each opening? | Applications per posting, per recruiter, recruiter workload | Applicant-tracking platform benchmarks (for example the Greenhouse benchmark report), Ashby or Lever reports |
| How long do hiring and searches take? | Time to fill; average duration of unemployment | Platform benchmarks; US BLS unemployment duration series; layoff-support sources that cite BLS |
| Which channels actually produce hires? | Share of applications vs share of hires by channel: referral, recruiter, company site, job board | Platform benchmarks that report both shares |
| Is the level being squeezed? | Headcount or posting trends for the specific level and function (director, manager, IC) | Industry-specific data posts, layoff trackers, LinkedIn data |
| What do postings in the user's target domain screen for? | Most-requested skills and proof, remote and hybrid mix, seniority mix | Posting analyses from recruiting firms and newsletters; read a sample of 10 to 20 current postings yourself |
| What do people in the same situation report? | Application counts, response rates, what worked, time to offer | Community threads, search-diary posts, coach write-ups. Label as reports, not data |
| Compensation context | Ranges for the role, level and region | Posted pay ranges in current listings, compensation datasets |
| Any local or sector effects? | Layoffs, hiring freezes, funding conditions in the user's industry and region | Recent news and sector reports |

## Query patterns
- "[role] job market [year]" plus "state of the [function] job market"
- "[platform] benchmark report [year] applications per hire by source"
- "average time to find a job after layoff [year]" and "BLS unemployment duration"
- "[level] [function] layoffs headcount [year]"
- "what [domain] [role] job postings ask for [year]"
- "[role] job search diary" and "[role] job search not getting interviews"

## Source hygiene
- Check the date; discard anything older than about 18 months unless it is the best available, and say so.
- If two sources disagree, show both and explain the likely reason (different populations, definitions, years).
- A single anecdote never carries a recommendation by itself.
- Re-verify any number before quoting it; do not rely on memory.
