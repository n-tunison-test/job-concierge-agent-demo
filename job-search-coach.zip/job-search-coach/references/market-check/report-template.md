# Market check report: template

Title: `Market check: <role and level>, <month year>`. Byline: date and the user.

## Bottom line
Three to five sentences. Is the market, the channel or the positioning the main issue? Is the search length normal? What to do first. Be specific to this person.

## The market right now
One sentence, then a table: Signal | What the data says | Source (linked, with date). Follow with 2 to 3 sentences on what it means for this person's level and domain.

## What others in your situation report
Bulleted. Each item states what the person reported, labelled report or claim, with the link. One line saying how it lines up with the data above.

## What is working and what is not
Two short lists backed by the sources, including channel effectiveness where available.

## How your search compares
Their funnel (applications, screens, interviews, offers, with stage-to-stage rates) and counts by channel, resume version, role type and domain. Mark groups under 10 as indicative only. State the bottleneck stage and the confidence. Include data-quality gaps that limit the comparison. Include a table or chart, with a table version.

## Where to focus
Ranked 3 to 5 changes. For each: change, evidence, stage helped, who or what makes it. Then one thing to stop. Then a checkpoint: what to measure and when.

## Changes to your tools
Optional, applied only with approval: Profile, scout criteria, resume rules, Tracker columns, review schedule.

## Sources
Linked list with publication date and what each measures.
